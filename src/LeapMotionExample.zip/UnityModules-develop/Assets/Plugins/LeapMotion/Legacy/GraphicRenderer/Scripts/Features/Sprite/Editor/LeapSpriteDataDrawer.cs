/******************************************************************************
 * Copyright (C) Ultraleap, Inc. 2011-2020.                                   *
 *                                                                            *
 * Use subject to the terms of the Apache License 2.0 available at            *
 * http://www.apache.org/licenses/LICENSE-2.0, or another agreement           *
 * between Ultraleap and you, your company or other organization.             *
 ******************************************************************************/

using System;
using UnityEngine;
using UnityEditor;

namespace Leap.Unity.GraphicalRenderer {

  [CustomPropertyDrawer(typeof(LeapSpriteData))]
  public class LeapSpriteDataDrawer : CustomPropertyDrawerBase {

    protected override void init(SerializedProperty property) {
      base.init(property);

      var channelFeature = LeapGraphicEditor.currentFeature as LeapSpriteFeature;
      Func<string> nameFunc = () => {
        if (channelFeature == null) {
          return null;
        } else {
          return channelFeature.propertyName;
        }
      };

      var spriteProp = property.FindPropertyRelative("_sprite");

      drawCustom(rect => {
        if (rect.height != 0) {
          var indentedRect = EditorGUI.IndentedRect(rect);
          EditorGUI.HelpBox(indentedRect, "Sprite is not packed!", MessageType.Error);
        }
      }, () => {
        Sprite sprite = spriteProp.objectReferenceValue as Sprite;
        if (sprite != null && !sprite.packed) {
          return EditorGUIUtility.singleLineHeight * 2;
        } else {
          return 0;
        }
      });

      drawProperty("_sprite", nameFunc);
    }
  }
}
