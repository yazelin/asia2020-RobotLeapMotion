/******************************************************************************
 * Copyright (C) Ultraleap, Inc. 2011-2020.                                   *
 *                                                                            *
 * Use subject to the terms of the Apache License 2.0 available at            *
 * http://www.apache.org/licenses/LICENSE-2.0, or another agreement           *
 * between Ultraleap and you, your company or other organization.             *
 ******************************************************************************/

using System;
using System.Linq;
using UnityEngine;
using UnityEditor;

namespace Leap.Unity.Packaging {

  [CustomEditor(typeof(BuildDefinition))]
  public class BuildDefinitionEditor : DefinitionBaseEditor<BuildDefinition> {

    protected override void OnEnable() {
      base.OnEnable();

      specifyCustomDecorator("_options", prop => drawExportFolder(prop, "Build", "Build Folder"));
      specifyCustomDrawer("_options", drawOptions);

      specifyCustomDecorator("_playerSettings", decorateBuildPlayerSettings);
      specifyCustomPostDecorator("_playerSettings", postDecorateBuildPlayerSettings);

      createList("_scenes", drawScene);
      createList("_targets", drawBuildTarget);
    }

    protected override void OnBuild() {
      target.Build();
    }

    protected override int GetBuildMenuPriority() {
      return 20;
    }

    protected override string GetBuildMethodName() {
      return "Build";
    }

    private void drawScene(Rect rect, SerializedProperty property) {
      float originalWidth = EditorGUIUtility.labelWidth;
      EditorGUIUtility.labelWidth *= 0.2f;

      string label = new string(property.displayName.Where(c => char.IsDigit(c)).ToArray());
      EditorGUI.PropertyField(rect, property, new GUIContent(label));

      EditorGUIUtility.labelWidth = originalWidth;
    }

    private void drawBuildTarget(Rect rect, SerializedProperty property) {
      EditorGUI.PropertyField(rect, property, GUIContent.none);
    }

    private void drawOptions(SerializedProperty prop) {
      EditorGUILayout.BeginHorizontal();

      EditorGUILayout.PropertyField(prop);

      if (GUILayout.Button("Debug", GUILayout.ExpandWidth(false))) {
        prop.intValue = (int)(BuildOptions.AllowDebugging |
                              BuildOptions.ConnectWithProfiler |
                              BuildOptions.Development |
                              BuildOptions.ForceEnableAssertions);
      }

      EditorGUILayout.EndHorizontal();
    }

    private void decorateBuildPlayerSettings(SerializedProperty prop) {
      var shouldDisable =
        !serializedObject.FindProperty("_useSpecificPlayerSettings").boolValue;
      
      EditorGUI.BeginDisabledGroup(shouldDisable);
    }
    private void postDecorateBuildPlayerSettings(SerializedProperty prop) {
      EditorGUI.EndDisabledGroup();
    }
  }
}
