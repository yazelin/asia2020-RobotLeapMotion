/******************************************************************************
 * Copyright (C) Ultraleap, Inc. 2011-2020.                                   *
 *                                                                            *
 * Use subject to the terms of the Apache License 2.0 available at            *
 * http://www.apache.org/licenses/LICENSE-2.0, or another agreement           *
 * between Ultraleap and you, your company or other organization.             *
 ******************************************************************************/

Leap Motion Core Assets

This module is the core dependency package for Leap Motion's Unity developer SDK.

You will need to have the Leap Motion service installed, which must be downloaded separately:
  https://developer.leapmotion.com/

Questions/Bugs/Feature Requests?
  Please post on https://community.leapmotion.com/c/development
