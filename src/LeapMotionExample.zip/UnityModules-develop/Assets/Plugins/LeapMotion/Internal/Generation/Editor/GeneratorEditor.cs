/******************************************************************************
 * Copyright (C) Ultraleap, Inc. 2011-2020.                                   *
 *                                                                            *
 * Use subject to the terms of the Apache License 2.0 available at            *
 * http://www.apache.org/licenses/LICENSE-2.0, or another agreement           *
 * between Ultraleap and you, your company or other organization.             *
 ******************************************************************************/

using System;
using UnityEngine;
using UnityEditor;

namespace Leap.Unity.Generation {

  [CanEditMultipleObjects]
  [CustomEditor(typeof(GeneratorBase), editorForChildClasses: true)]
  public class GeneratorEditor : CustomEditorBase<GeneratorBase> {

    [MenuItem("Assets/Run All Generators")]
    public static void TriggerGeneration() {
      int successfulGenerators = 0;
      int failedGenerators = 0;
      foreach (var gen in EditorResources.FindAllAssetsOfType<GeneratorBase>()) {
        try {
          gen.Generate();
          successfulGenerators++;
        } catch (Exception e) {
          Debug.LogException(e);
          failedGenerators++;
        }
      }

      if (successfulGenerators == 1) {
        Debug.Log("Successfully ran 1 generator.");
      } else if (successfulGenerators > 1) {
        Debug.Log("Successfully ran " + successfulGenerators + " generators.");
      }

      if (failedGenerators == 1) {
        Debug.LogError("1 generator failed to run.");
      } else if (failedGenerators > 1) {
        Debug.LogError(failedGenerators + " generators failed to run.");
      }

      AssetDatabase.Refresh();
      AssetDatabase.SaveAssets();
    }

    protected override void OnEnable() {
      base.OnEnable();

      dontShowScriptField();
    }

    public override void OnInspectorGUI() {
      drawScriptField();

      if (GUILayout.Button("Generate")) {
        foreach (var target in targets) {
          target.Generate();
        }

        AssetDatabase.Refresh();
        AssetDatabase.SaveAssets();
      }

      base.OnInspectorGUI();
    }
  }
}
